# Predicting_Liver_Cirrhosis-using-Advanced-Machine-Learning
This project uses various advanced machine learning techniques to predict liver cirrhosis based on clinical and biochemical data. The main objective is to assist in the early detection of liver damage to improve treatment and health outcomes.
